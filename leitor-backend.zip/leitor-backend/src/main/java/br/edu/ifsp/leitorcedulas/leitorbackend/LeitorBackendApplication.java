package br.edu.ifsp.leitorcedulas.leitorbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LeitorBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(LeitorBackendApplication.class, args);
	}

}
