package br.edu.ifsp.leitorcedulas.leitorbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeitorBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
